package com.example.livetranslate

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View
import kotlin.math.max

/** 번역된 문장을 원문 위치에 덮어 그리는 투명 전체화면 뷰 */
class OverlayView(context: Context) : View(context) {

    data class Item(val rect: Rect, val text: String)

    var items: List<Item> = emptyList()
        set(value) {
            field = value
            invalidate()
        }

    private val bgPaint = Paint().apply { color = 0xE6141420.toInt() }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    override fun onDraw(canvas: Canvas) {
        val pad = 8f
        for (item in items) {
            val boxW = max(item.rect.width() + pad * 2, 200f)
            val textW = (boxW - pad * 2).toInt()

            var size = 56f
            var layout: StaticLayout
            while (true) {
                textPaint.textSize = size
                layout = StaticLayout.Builder
                    .obtain(item.text, 0, item.text.length, textPaint, textW)
                    .build()
                if (layout.height <= item.rect.height() + pad || size <= 20f) break
                size -= 2f
            }

            val boxH = max(item.rect.height() + pad * 2, layout.height + pad * 2)
            val left = item.rect.left - pad
            val top = item.rect.top - pad
            canvas.drawRoundRect(left, top, left + boxW, top + boxH, 12f, 12f, bgPaint)
            canvas.save()
            canvas.translate(left + pad, top + pad)
            layout.draw(canvas)
            canvas.restore()
        }
    }
}
