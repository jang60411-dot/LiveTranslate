package com.example.livetranslate

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlin.math.abs

class TranslateService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "com.example.livetranslate.STOP"
        private const val CHANNEL = "live_translate"
        private const val AUTO_INTERVAL_MS = 1200L
        @Volatile var running = false
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val uiHandler = Handler(Looper.getMainLooper())

    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private lateinit var captureThread: HandlerThread
    private lateinit var captureHandler: Handler
    private val lock = Any()
    private var latest: Image? = null
    private var capW = 0
    private var capH = 0
    private var dpi = 0

    private lateinit var overlay: OverlayView
    private lateinit var button: View
    private lateinit var buttonParams: WindowManager.LayoutParams

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)   // 원문 언어
            .setTargetLanguage(TranslateLanguage.KOREAN)    // 번역 언어
            .build()
    )
    private val cache = HashMap<String, String>()

    private var autoJob: Job? = null
    private var busy = false
    private var showing = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Android 14: getMediaProjection 전에 반드시 mediaProjection 타입으로 startForeground
        startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        wm = getSystemService(WindowManager::class.java)
        captureThread = HandlerThread("capture").also { it.start() }
        captureHandler = Handler(captureThread.looper)
        dpi = resources.displayMetrics.densityDpi

        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data).also { p ->
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSelf()
                }
            }, uiHandler)
        }

        createDisplay()
        createOverlayViews()
        running = true
        Toast.makeText(this, "실시간 번역 시작! 파란 버튼을 눌러보세요", Toast.LENGTH_LONG).show()
        return START_NOT_STICKY
    }

    // ───────────── 화면 캡처 ─────────────

    @Suppress("DEPRECATION")
    private fun realSize(): Pair<Int, Int> {
        val m = DisplayMetrics()
        getSystemService(DisplayManager::class.java)
            .getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m)
        return m.widthPixels to m.heightPixels
    }

    private fun newReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ ir ->
            val img = try { ir.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) {
                synchronized(lock) {
                    latest?.close()
                    latest = img
                }
            }
        }, captureHandler)
        return r
    }

    private fun createDisplay() {
        val (w, h) = realSize()
        capW = w; capH = h
        val r = newReader(w, h)
        reader = r
        // Android 14+: createVirtualDisplay는 projection당 1번만 호출 가능 → 이후엔 resize/setSurface 사용
        virtualDisplay = projection!!.createVirtualDisplay(
            "live-translate", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, null
        )
    }

    /** 화면 회전(세로↔가로)이 바뀌었으면 캡처 크기를 맞춘다 */
    private suspend fun ensureDisplay() {
        val (w, h) = realSize()
        if (w == capW && h == capH) return
        val newR = newReader(w, h)
        virtualDisplay?.resize(w, h, dpi)
        virtualDisplay?.surface = newR.surface
        synchronized(lock) { latest?.close(); latest = null }
        reader?.close()
        reader = newR
        capW = w; capH = h
        wm.updateViewLayout(overlay, overlayParams(w, h, touchable = false))
        delay(400)
    }

    private fun toBitmap(img: Image): Bitmap {
        val plane = img.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * img.width
        val full = Bitmap.createBitmap(
            img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888
        )
        full.copyPixelsFromBuffer(plane.buffer)
        return Bitmap.createBitmap(full, 0, 0, img.width, img.height)
    }

    private suspend fun captureBitmap(): Bitmap? {
        ensureDisplay()
        repeat(15) {
            val bmp = synchronized(lock) { latest?.let { toBitmap(it) } }
            if (bmp != null) return bmp
            delay(100)
        }
        return null
    }

    // ───────────── OCR + 번역 ─────────────

    private suspend fun translateOnce() {
        if (busy) return
        busy = true
        try {
            overlay.visibility = View.INVISIBLE   // 내 번역문이 OCR되지 않도록 잠깐 숨김
            delay(250)
            val bmp = captureBitmap()
            if (bmp == null) {
                Toast.makeText(this, "화면을 캡처하지 못했어요", Toast.LENGTH_SHORT).show()
                return
            }
            val result = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
            bmp.recycle()

            val blocks = result.textBlocks.filter {
                it.boundingBox != null && it.text.length >= 2 && it.text.any(Char::isLetter)
            }
            if (cache.size > 500) cache.clear()
            val items = coroutineScope {
                blocks.map { b ->
                    async {
                        val src = b.text.replace("\n", " ").trim()
                        val ko = cache[src]
                            ?: translator.translate(src).await().also { cache[src] = it }
                        OverlayView.Item(b.boundingBox!!, ko)
                    }
                }.awaitAll()
            }
            overlay.items = items
            showing = items.isNotEmpty()
        } catch (e: Exception) {
            Toast.makeText(this, "번역 실패: ${e.message}", Toast.LENGTH_SHORT).show()
        } finally {
            overlay.visibility = View.VISIBLE
            busy = false
        }
    }

    private fun clearOverlay() {
        overlay.items = emptyList()
        showing = false
    }

    private fun toggleAuto() {
        if (autoJob != null) {
            stopAuto()
            clearOverlay()
            Toast.makeText(this, "자동 모드 꺼짐", Toast.LENGTH_SHORT).show()
        } else {
            setButtonColor(0xCC22C55E.toInt())
            Toast.makeText(this, "자동 모드 켜짐", Toast.LENGTH_SHORT).show()
            autoJob = scope.launch {
                while (isActive) {
                    translateOnce()
                    delay(AUTO_INTERVAL_MS)
                }
            }
        }
    }

    private fun stopAuto() {
        autoJob?.cancel()
        autoJob = null
        setButtonColor(0xCC3B82F6.toInt())
    }

    private fun onTap() {
        when {
            autoJob != null -> { stopAuto(); clearOverlay() }
            showing -> clearOverlay()
            else -> scope.launch { translateOnce() }
        }
    }

    // ───────────── 오버레이 / 플로팅 버튼 ─────────────

    private fun overlayParams(w: Int, h: Int, touchable: Boolean) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = android.view.Gravity.TOP or android.view.Gravity.START
        layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
    }

    private fun setButtonColor(color: Int) {
        (button.background as? GradientDrawable)?.setColor(color)
    }

    private fun createOverlayViews() {
        overlay = OverlayView(this)
        wm.addView(overlay, overlayParams(capW, capH, touchable = false))

        val size = (56 * resources.displayMetrics.density).toInt()
        button = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC3B82F6.toInt())
                setStroke(4, 0xFFFFFFFF.toInt())
            }
        }
        buttonParams = overlayParams(size, size, touchable = true).apply {
            x = 24; y = 300
        }
        button.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var px = 0; var py = 0
            var moved = false; var longFired = false
            val longPress = Runnable { if (!moved) { longFired = true; toggleAuto() } }

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX; sy = e.rawY
                        px = buttonParams.x; py = buttonParams.y
                        moved = false; longFired = false
                        uiHandler.postDelayed(longPress, 600)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx; val dy = e.rawY - sy
                        if (abs(dx) > 12 || abs(dy) > 12) {
                            moved = true
                            uiHandler.removeCallbacks(longPress)
                        }
                        if (moved) {
                            buttonParams.x = px + dx.toInt()
                            buttonParams.y = py + dy.toInt()
                            wm.updateViewLayout(v, buttonParams)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        uiHandler.removeCallbacks(longPress)
                        if (!moved && !longFired) onTap()
                    }
                    MotionEvent.ACTION_CANCEL -> uiHandler.removeCallbacks(longPress)
                }
                return true
            }
        })
        wm.addView(button, buttonParams)
    }

    // ───────────── 알림 / 정리 ─────────────

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "실시간 번역", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, TranslateService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("실시간 번역 실행 중")
            .setContentText("파란 버튼: 번역 · 길게 누르기: 자동 모드")
            .addAction(Notification.Action.Builder(null as Icon?, "중지", stop).build())
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        running = false
        autoJob?.cancel()
        scope.cancel()
        uiHandler.removeCallbacksAndMessages(null)
        runCatching { wm.removeView(button) }
        runCatching { wm.removeView(overlay) }
        synchronized(lock) { latest?.close(); latest = null }
        virtualDisplay?.release()
        reader?.close()
        projection?.stop()
        if (::captureThread.isInitialized) captureThread.quitSafely()
        recognizer.close()
        translator.close()
        super.onDestroy()
    }
}
