package com.example.livetranslate

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.common.model.DownloadConditions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private var askedNotification = false

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // 거부해도 서비스는 동작함(알림만 안 보임) → 계속 진행
            startFlow()
        }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val svc = Intent(this, TranslateService::class.java)
                    .putExtra(TranslateService.EXTRA_CODE, r.resultCode)
                    .putExtra(TranslateService.EXTRA_DATA, data)
                startForegroundService(svc)
                status.text = "실행 중! 번역할 앱으로 이동하세요.\n파란 버튼 탭 = 번역 / 길게 누르기 = 자동 모드"
                moveTaskToBack(true)
            } else {
                status.text = "화면 캡처 권한이 거부되었어요."
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "실시간 화면 번역 (영어 → 한국어)"
            textSize = 20f
            gravity = Gravity.CENTER
        })
        status = TextView(this).apply {
            text = "시작 버튼을 누르면 필요한 권한을 차례로 안내해요."
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad)
        }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "시작"
            setOnClickListener { startFlow() }
        })
        root.addView(Button(this).apply {
            text = "중지"
            setOnClickListener {
                stopService(Intent(this@MainActivity, TranslateService::class.java))
                status.text = "중지됨"
            }
        })
        setContentView(root)
    }

    private fun startFlow() {
        // 1) 다른 앱 위에 표시 권한
        if (!Settings.canDrawOverlays(this)) {
            status.text = "'다른 앱 위에 표시' 권한을 켜고 돌아와서 다시 시작을 눌러주세요."
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        // 2) 알림 권한 (Android 13+)
        if (Build.VERSION.SDK_INT >= 33 && !askedNotification &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotification = true
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        // 3) 번역 모델 다운로드 (최초 1회)
        lifecycleScope.launch {
            status.text = "번역 모델 준비 중… (처음 한 번만, 수십 MB)"
            val translator = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.ENGLISH)
                    .setTargetLanguage(TranslateLanguage.KOREAN)
                    .build()
            )
            try {
                translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            } catch (e: Exception) {
                status.text = "모델 다운로드 실패: 인터넷 연결을 확인해주세요.\n(${e.message})"
                return@launch
            } finally {
                translator.close()
            }
            // 4) 화면 캡처 동의
            val mpm = getSystemService(MediaProjectionManager::class.java)
            projectionLauncher.launch(mpm.createScreenCaptureIntent())
        }
    }
}
